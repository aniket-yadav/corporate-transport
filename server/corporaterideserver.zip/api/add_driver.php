<?php
require('init.php');
$name = $_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$mobile = $_POST['mobile'];
$aadharno = $_POST['aadharno'];
$experience = $_POST['experience'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$driverid = uniqid("dr");
$username = strstr($email,'@',true);
function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $pass ="";
    $alphaLength = strlen($alphabet) - 1; 
 for ($i = 0; $i < 8; $i++) {
     $pass.= $alphabet[random_int(0, $alphaLength)];
    }
    return $pass;
}

$password=randomPassword();
$pass = md5($password);
$role = "driver";

$sql="INSERT INTO `drivers` (`driverid`, `username`, `email`, `password`, `role`, `mobile`, `gender`, `age`, `experience`, `address`, `pincode`, `aadharno`, `name`) VALUES ('$driverid', '$username', '$email', '$pass', '$role', '$mobile', '$gender', '$age', '$experience', '$address', '$pincode', '$aadharno', '$name');";
$result=mysqli_query($conn,$sql);

$res = array();
if($result){

$to = $email;
					$subject = "Username and Password";

					$message = "Hello User,<br><br>
					your account has been created.<br><br>
					Your username and password are given below:<br>
					Username: $username<br>
					Password: $password<br>
					<br><br><br><br>
					Thank You,<br>
					Corporate Ride team";

					$header = "From:corporateride \r\n";
					$header .= "MIME-Version: 1.0\r\n";
					$header .= "Content-type: text/html\r\n";

					if( mail($to,$subject,$message,$header)){
						
$res['success']=true;
$res['message']="Record added and mail sent";
						
					}else{
					    $res['success']=true;
$res['message']="Record added";
					}

}else{
$res['success']=false;
$res['message']="Failed to add record";
$res['error']= mysqli_connect_error();

}
echo json_encode($res);
?>