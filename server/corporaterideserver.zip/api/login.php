<?php
require('init.php');

$username = $_POST['username'];
$password = $_POST['password'];
$passmd5 = md5($password);
$sql="select * from `users` where `username`='$username' and `password`='$passmd5'";
$result=mysqli_query($conn,$sql);

$arr=array();
if(mysqli_num_rows($result)>0){
$row=mysqli_fetch_assoc($result);
     $arr['success']=true;
    $arr['message']="Login successful";
    $arr['role'] = $row['role'];
    $arr['userid'] = $row['userid'];
}else{
    $arr['success']=false;
    $arr['message']="username/password doesn't match";
    $arr['error'] = mysqli_error($conn);
}
echo json_encode($arr);
?>