<?php
require('init.php');
$name =$_POST['name'];
$model = $_POST['model']     ;
$type = $_POST['type'];
$color = $_POST['color'];
$no = $_POST['no'];
$capacity = $_POST['capacity'];
$vehicleid = uniqid("ve");
      

$sql="INSERT INTO `vehicles` (`vehicleid`, `name`, `model`, `platno`, `color`, `type`, `capacity`) VALUES ('$vehicleid', '$name', '$model', '$no', '$color', '$type', '$capacity')";
$result=mysqli_query($conn,$sql);

$res = array();
if($result){
$res['success']=true;
$res['message']="Record added";
}else{
$res['success']=false;
$res['message']="Failed to add record";
$res['err']=mysqli_connect_error();
}
echo json_encode($res);
?>