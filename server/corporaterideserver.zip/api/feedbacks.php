<?php
require('init.php');

$sql="select * from feedbacks order by date DESC";
$result=mysqli_query($conn,$sql);

$arr = array();
$res = array();
if($result){
if(mysqli_num_rows($result)>0){

    while($row=mysqli_fetch_assoc($result)){
        array_push($arr,$row);
    }
    $res['success'] = true;
    $res['message'] = '';
    $res['data'] = $arr;
}else{
    $res['success'] = true;
    $res['message'] = "No feedback available";
    $res['data'] = $arr;
}
}else{
    $res['success'] = false;
    $res['message'] = 'Failed to get feedbacks';
    $res['data'] = $arr;
}
echo json_encode($res);
?>