<?php
require('init.php');
$id = $_POST['id'];
$res = array();
$status = "true";
 
 
    $sql = "UPDATE `billing` SET `paymentStatus`='$status'  WHERE `billId`='$id'";


$result=mysqli_query($conn,$sql);


if($result){
$res['success']=true;
$res['message']="Successful";
}else{
$res['success']=false;
$res['message']="Failed";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>


