<?php
require('init.php');
$vehicleId = $_POST['vehicleId'];
$longitude = $_POST['longitude'];
$latitude = $_POST['latitude'];
$res = array();
$sql="";

 
 
    $sql = "UPDATE `vehicles` SET `longitude`='$longitude', `latitude`='$latitude'  WHERE `vehicleid`='$vehicleId'";


$result=mysqli_query($conn,$sql);


if($result){
$res['success']=true;
$res['message']="Successful";
}else{
$res['success']=false;
$res['message']="Failed";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>


