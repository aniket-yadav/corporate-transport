<?php  
require('init.php');
 $orderId = $_POST["orderId"];
 $orderAmount = $_POST["orderAmount"];
 $referenceId = $_POST["referenceId"];
 $txStatus = $_POST["txStatus"];
 $paymentMode = $_POST["paymentMode"];
 $txMsg = $_POST["txMsg"];
 $txTime = $_POST["txTime"];
 $signature = $_POST["signature"];
 $bookingid = $_POST['bookingid'];
 $secretkey = 'b47ee150d2719b8200f67a524ef52896cc6898c7';
 $res = array();
 $data = $orderId.$orderAmount.$referenceId.$txStatus.$paymentMode.$txMsg.$txTime;
 $hash_hmac = hash_hmac('sha256', $data, $secretkey, true) ;
 $computedSignature = base64_encode($hash_hmac);
 if ($signature == $computedSignature) {
     
     
    $sql = "UPDATE `billing` SET `paymentStatus`='true',`paymentid`='$orderId' WHERE `billId`='$bookingid'";



$result=mysqli_query($conn,$sql);


if($result){
$res['success'] = true;
     $res['message'] = "Payment Succeful";
}else{
$res['success']=true;
$res['message']="Failed to update payment status";
}

    
  } else {
   $res['success'] = false;
     $res['message'] = "Payment falied";
 }
 
 echo json_encode($res);
 ?>
 
 