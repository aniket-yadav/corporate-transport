<?php
require('init.php');
$vehicleId = $_POST['id'];
$name =$_POST['name'];
$model = $_POST['model'];
$type = $_POST['type'];
$color = $_POST['color'];
$no = $_POST['no'];
$capacity = $_POST['capacity'];
$res = array();


 
 
    $sql = "UPDATE `vehicles` SET `name`='$name', `model`='$model',`platno`='$no',`color`='$color',`type`='$type',`capacity`='$capacity'  WHERE `vehicleid`='$vehicleId'";


$result=mysqli_query($conn,$sql);


if($result){
$res['success']=true;
$res['message']="Successful";
}else{
$res['success']=false;
$res['message']="Failed";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>


