<?php
require('init.php');
$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$mobile = $_POST['mobile'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$experince =$_POST['experience'];
$aadhar = $_POST['aadharno'];

$res = array();

    $sql = "UPDATE `drivers` SET  `name` = '$name', `email`='$email', `age`='$age',`gender`='$gender',`mobile`='$mobile', `address`='$address', `pincode`='$pincode', `experience`='$experince',`aadharno`='$aadhar' WHERE `driverid`='$id'";


$result=mysqli_query($conn,$sql);


if($result){
$res['success']=true;
$res['message']="Successful";
}else{
$res['success']=false;
$res['message']="Failed";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>


