<?php
require('init.php');
$name = $_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$mobile = $_POST['mobile'];
$empid = $_POST['empid'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$employeeid = uniqid("emp");
$username = strstr($email,'@',true);
function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $pass ="";
    $alphaLength = strlen($alphabet) - 1; 
 for ($i = 0; $i < 8; $i++) {
     $pass.= $alphabet[random_int(0, $alphaLength)];
    }
    return $pass;
}

$password=randomPassword();

$pass = md5($password);
$role = "employee";

$sql="INSERT INTO `employee` (`employeeid`, `username`, `password`, `email`, `role`, `mobile`, `gender`, `age`, `empid`, `address`, `pincode`,  `name`) VALUES ('$employeeid', '$username', '$pass', '$email', '$role', '$mobile', '$gender', '$age', '$empid', '$address', '$pincode',  '$name')";
$result=mysqli_query($conn,$sql);

$res = array();
if($result){

$to = $email;
					$subject = "Username and Password";

					$message = "Hello User,<br><br>
					your account has been created.<br><br>
					Your username and password are given below:<br>
					Username: $username<br>
					Password: $password<br>
					<br><br><br><br>
					Thank You,<br>
					Corporate Ride team";

					$header = "From:corporateride \r\n";
					$header .= "MIME-Version: 1.0\r\n";
					$header .= "Content-type: text/html\r\n";

					if( mail($to,$subject,$message,$header)){
						
$res['success']=true;
$res['message']="Record added and mail sent";
						
					}else{
					    $res['success']=true;
$res['message']="Record added";
					}


}else{
$res['success']=false;
$res['message']="Failed to add record";
$res['err']=mysqli_connect_error();
}
echo json_encode($res);
?>