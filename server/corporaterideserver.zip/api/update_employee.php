<?php
require('init.php');
$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$mobile = $_POST['mobile'];
$empid = $_POST['empid'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$res = array();

    $sql = "UPDATE `employee` SET  `name` = '$name', `email`='$email', `age`='$age',`gender`='$gender',`mobile`='$mobile', `empid`='$empid', `address`='$address', `pincode`='$pincode' WHERE `employeeid`='$id'";


$result=mysqli_query($conn,$sql);


if($result){
$res['success']=true;
$res['message']="Successful";
}else{
$res['success']=false;
$res['message']="Failed";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>


