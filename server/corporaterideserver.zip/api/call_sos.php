<?php
require('init.php');

$user = $_POST['user'];
$lat = $_POST['lat'];
$log = $_POST['log'];
$userid = $_POST['userid'];

$sql="select * from `admin`";
$result=mysqli_query($conn,$sql);


$res =array();
if($result){
if(mysqli_num_rows($result)>0){

    while($row=mysqli_fetch_assoc($result)){
        
        $email = $row['email'];
        $to = $email;
		$subject = "SOS CALL";

		$message = "Hey Admin,<br><br><br>
					Got SOS call from $user.<br><br>
					userId: $userid<br><br>
				    
					Paste the below co-ordinates in google map to get the exact location.<br><br>
					Co-ordinates: $lat,$log
					<br><br><br>
					
					
					Thank You,<br>
					Corporate Ride team";

					$header = "From:corporateride \r\n";
					$header .= "MIME-Version: 1.0\r\n";
					$header .= "Content-type: text/html\r\n";

					if( mail($to,$subject,$message,$header)){
						

						
					}
    }
    $res['success'] = true;
    $res['message'] = "SOS Sent";
    
}
}else{
   $res['success']=false;
    $res['message']='faild to sent';
    
}
echo json_encode($res);
?>