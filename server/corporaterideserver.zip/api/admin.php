<!DOCTYPE HTML>
<html>  
<body>

<form action="add_admin.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Mobile: <input type="text" name="mobile"><br>
gender: <input type="text" name="gender"><br>
Age: <input type="text" name="age"><br>
<input type="submit">
</form>

</body>
</html>