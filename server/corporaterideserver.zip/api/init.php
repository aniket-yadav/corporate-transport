<?php

    $server = "localhost";
    $user = "u302425375_ajay";
    $password = "Ajay@1234";
    $database = "u302425375_corporateride";
    $conn = mysqli_connect($server, $user, $password, $database);

?>