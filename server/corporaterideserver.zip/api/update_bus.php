<?php
require('init.php');
$user = $_POST['user'];
$userId = $_POST['userid'];
$busId = $_POST['bus'];
$res = array();
$sql="";

 if($user == "driver"){
    $sql = "UPDATE `drivers` SET `vehicleid`='$busId' WHERE `driverid`='$userId'";
    $bussql = "UPDATE `vehicles` SET `driverid`='$userId' WHERE `vehicleid`='$busId'";
}else if($user == "employee"){
     $sql = "UPDATE `employee` SET `vehicleid`='$busId' WHERE `employeeid`='$userId'";
}

if($user == "driver"){
   $result2=mysqli_query($conn,$bussql);
}
$result=mysqli_query($conn,$sql);


if($result){
$res['success']=true;
$res['message']="Successful";
}else{
$res['success']=false;
$res['message']="Failed";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>


