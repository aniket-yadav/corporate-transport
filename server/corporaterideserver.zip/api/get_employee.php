<?php
require('init.php');

$userid = $_POST['userid'];

$sql="select * from employee where employeeid='$userid'";
$result=mysqli_query($conn,$sql);

$arr=array();
if(mysqli_num_rows($result)>0){
$row=mysqli_fetch_assoc($result);
     $arr['success']=true;
    $arr['message']="";
    $arr['data'] = $row;
}else{
    $arr['success']=false;
    $arr['message']="Failed to fetch data";
}
echo json_encode($arr);
?>