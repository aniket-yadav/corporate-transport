<?php
require('init.php');
$name = $_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$mobile = $_POST['mobile'];

$adminid = uniqid("ad");
$username = strstr($email,'@',true);
function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $pass ="";
    $alphaLength = strlen($alphabet) - 1; 
 for ($i = 0; $i < 8; $i++) {
     $pass.= $alphabet[random_int(0, $alphaLength)];
    }
    return $pass;
}

$password=randomPassword();

$pass = md5($password);
$role = "admin";

$sql="INSERT INTO `admin` (`adminid`, `username`, `password`, `email`, `role`,`gender`,`age`, `mobile`, `name`) VALUES ('$adminid', '$username', '$pass', '$email', '$role','$gender','$age' ,'$mobile',   '$name')";
$result=mysqli_query($conn,$sql);

$res = array();
if($result){

$to = $email;
					$subject = "Username and Password";

					$message = "Hello User,<br><br>
					your account has been created.<br><br>
					Your username and password are given below:<br>
					Username: $username<br>
					Password: $password<br>
					<br><br><br><br>
					Thank You,<br>
					Automobile Service team";

					$header = "From:automibileservice \r\n";
					$header .= "MIME-Version: 1.0\r\n";
					$header .= "Content-type: text/html\r\n";

					if( mail($to,$subject,$message,$header)){
						
$res['success']=true;
$res['message']="Record added and mail sent";
						
					}else{
					    $res['success']=true;
$res['message']="Record added";
					}


}else{
$res['success']=false;
$res['message']="Failed to add record";
$res['err']=mysqli_connect_error();
$res['sql'] = $sql;
}
echo json_encode($res);
?>