<?php
require('init.php');
$employeeId = $_POST['employeeId'];
$bus = $_POST['bus'];
$duration = $_POST['duration'];
$billId = uniqid("bi");
$status = "false";     
$amount = "700";

$sql="INSERT INTO `billing` (`billId`, `employeeId`, `bus`, `billingMonthYear`, `paymentStatus`,`amount`) VALUES ('$billId','$employeeId','$bus','$duration','$status','$amount')";
$result=mysqli_query($conn,$sql);

$res = array();
if($result){
$res['success']=true;
$res['message']="Bill generated";
}else{
$res['success']=false;
$res['message']="Failed";
$res['err']=mysqli_connect_error();
}
echo json_encode($res);
?>