<?php
require('init.php');
$image = $_POST['image'];
$userid = $_POST['userid'];
$role = $_POST['role'];
$sql = '';
if($role == "admin"){
$sql ="update admin set image='$image' where adminid='$userid'";    
}else if($role == "driver"){
$sql ="update drivers set image='$image' where driverid='$userid' ";        
}else if($role == "employee"){
$sql ="update employee set image='$image' where employeeid='$userid' ";            
}

$result=mysqli_query($conn,$sql);

$res = array();
if($result){
$res['success']=true;
$res['message']="Profile picture updated";
}else{
$res['success']=false;
$res['message']="Failed to update";
}
echo json_encode($res);
?>